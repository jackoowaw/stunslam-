package dev.pvplite;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper; // ggf. KeyBindingHelper je nach Fabric-API-Stand
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.function.Predicate;

/**
 * Alle Module laufen automatisch. Einzige Taste: H = Menue (Module an/aus).
 */
public class PvpLiteClient implements ClientModInitializer {
    private static final KeyMapping.Category CAT =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath("pvplite", "main"));
    private KeyMapping kMenu;

    private static final class Task { int ticks; final Runnable run; Task(int t, Runnable r) { ticks = t; run = r; } }
    private final List<Task> tasks = new ArrayList<>();
    private final Random rng = new Random();

    static int stunCooldown = 0, spearCooldown = 0, gappleCooldown = 0;
    private boolean comboRunning = false;
    // Auto-Gapple Zustand
    private boolean eating = false, eatStarted = false;
    private int eatTicks = 0, eatOldSlot = 0;

    @Override
    public void onInitializeClient() {
        Config.load();
        kMenu = KeyMappingHelper.registerKeyMapping(new KeyMapping("key.pvplite.menu", GLFW.GLFW_KEY_H, CAT));
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        HudElementRegistry.attachElementAfter(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("pvplite", "hud"), (g, tick) -> {
            if (!Config.showHud) return;
            Minecraft m = Minecraft.getInstance();
            if (m.player == null || m.options.hideGui) return;
            String[] lines = {
                "PvP Lite  [H = Menue]",
                "Auto Stun Slam: " + onOff(Config.stunSlam) + (stunCooldown > 0 ? String.format("  (%.1fs)", stunCooldown / 20.0) : ""),
                "Auto Spear Swap: " + onOff(Config.spearSwap),
                "Auto Gapple: " + onOff(Config.autoGapple)
            };
            int y = 4;
            for (String l : lines) { g.drawString(m.font, l, 4, y, 0xFFFFFFFF); y += 10; }
        });
    }

    private void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null || mc.level == null) {
            tasks.clear(); comboRunning = false; eating = false; return;
        }

        for (Iterator<Task> it = tasks.iterator(); it.hasNext(); ) {
            Task t = it.next();
            if (--t.ticks <= 0) { it.remove(); t.run.run(); }
        }
        if (stunCooldown > 0) stunCooldown--;
        if (spearCooldown > 0) spearCooldown--;
        if (gappleCooldown > 0) gappleCooldown--;

        while (kMenu.consumeClick()) mc.setScreen(new ConfigScreen());
        if (mc.screen != null) return;

        if (eating) { tickEating(mc, p); return; }

        if (Config.autoGapple) autoGapple(mc, p);
        if (eating) return;
        if (Config.stunSlam) autoStunSlam(mc, p);
        if (Config.spearSwap) autoSpear(mc, p);
    }

    // ---------- Auto Stun Slam: dein Angriffs-Klick auf Spieler ----------
    private void autoStunSlam(Minecraft mc, LocalPlayer p) {
        if (comboRunning || stunCooldown > 0 || !mc.options.keyAttack.isDown()) return;
        if (!(mc.hitResult instanceof EntityHitResult hit)) return;   // Vanilla-Reichweite, kein Auto-Aim
        if (!(hit.getEntity() instanceof Player victim) || victim == p) return;

        int axe = findSlot(p, s -> s.is(ItemTags.AXES));
        int mace = findSlot(p, s -> s.is(Items.MACE));
        if (mace < 0) return;

        if (!victim.isBlocking()) {
            // Kein Schild: nur wenn "Axt nur bei Schild" AUS ist, laeuft die Combo trotzdem
            if (Config.stunSlamOnlyIfBlocking) return;
        }
        if (axe < 0 || p.getAttackStrengthScale(0f) < (float) Config.minAttackStrength) return;

        comboRunning = true;
        int old = selected(p);
        swapAttack(mc, p, axe, victim);                                   // 1) Schild disablen
        int delay = Config.stunSlamDelayMin + rng.nextInt(Math.max(1, Config.stunSlamDelayJitter + 1));
        tasks.add(new Task(delay, () -> {                                  // 2) Mace beim Fall
            LocalPlayer pl = mc.player;
            if (pl != null && victim.isAlive() && pl.fallDistance >= Config.minFallDistance
                    && pl.getAttackStrengthScale(0f) >= (float) Config.minAttackStrength
                    && pl.distanceTo(victim) < 4.5)
                swapAttack(mc, pl, mace, victim);
            if (pl != null) select(pl, old);
            comboRunning = false;
            stunCooldown = Config.stunSlamCooldownTicks;
        }));
    }

    // ---------- Auto Spear Swap: beim Sprint auf einen Spieler zu ----------
    private void autoSpear(Minecraft mc, LocalPlayer p) {
        if (spearCooldown > 0 || comboRunning || !p.isSprinting()) return;
        int spear = findSlot(p, s -> s.is(ItemTags.SPEARS));
        if (spear < 0 || selected(p) == spear) return;
        Vec3 look = p.getLookAngle();
        for (Player other : mc.level.players()) {
            if (other == p || !other.isAlive()) continue;
            Vec3 to = other.getEyePosition().subtract(p.getEyePosition());
            double dist = to.length();
            if (dist > Config.spearTriggerRange || dist < 1.0) continue;
            if (look.dot(to.normalize()) < 0.95 || !p.hasLineOfSight(other)) continue;
            int old = selected(p);
            select(p, spear);
            spearCooldown = Config.spearCooldownTicks;
            tasks.add(new Task(Config.spearReturnTicks, () -> {
                LocalPlayer pl = mc.player;
                if (pl != null && selected(pl) == spear) select(pl, old);
            }));
            return;
        }
    }

    // ---------- Auto Gapple: bei niedriger HP ----------
    private void autoGapple(Minecraft mc, LocalPlayer p) {
        if (gappleCooldown > 0 || p.isUsingItem() || p.getHealth() > Config.gappleHealth || !p.isAlive()) return;
        int slot = findSlot(p, s -> s.is(Items.GOLDEN_APPLE) || s.is(Items.ENCHANTED_GOLDEN_APPLE));
        if (slot < 0) return;
        eatOldSlot = selected(p);
        select(p, slot);
        eating = true; eatStarted = false; eatTicks = 0;
    }

    private void tickEating(Minecraft mc, LocalPlayer p) {
        eatTicks++;
        mc.options.keyUse.setDown(true);
        if (p.isUsingItem()) eatStarted = true;
        boolean done = (eatStarted && !p.isUsingItem()) || eatTicks > 60 || !p.isAlive();
        if (done) {
            mc.options.keyUse.setDown(false);
            select(p, eatOldSlot);
            eating = false;
            gappleCooldown = Config.gappleCooldownTicks;
        }
    }

    // ---------- Helfer ----------
    private void swapAttack(Minecraft mc, LocalPlayer p, int slot, Entity target) {
        select(p, slot);
        mc.gameMode.attack(p, target);
        p.swing(InteractionHand.MAIN_HAND);
    }
    private static int findSlot(LocalPlayer p, Predicate<ItemStack> m) {
        for (int i = 0; i < 9; i++) if (m.test(p.getInventory().getItem(i))) return i;
        return -1;
    }
    private static int selected(LocalPlayer p) { return p.getInventory().getSelectedSlot(); }
    private static void select(LocalPlayer p, int slot) { p.getInventory().setSelectedSlot(slot); }
    private static String onOff(boolean b) { return b ? "AN" : "AUS"; }
}

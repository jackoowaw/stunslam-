package dev.pvplite;

import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.function.BooleanSupplier;

/** Menue (Taste H): alle Module per Klick an/aus, plus ein paar Balance-Werte. */
public class ConfigScreen extends Screen {
    public ConfigScreen() { super(Component.literal("PvP Lite")); }

    private int row = 0;
    private static final int W = 200, H = 20, GAP = 24;

    private void toggle(String name, BooleanSupplier get, Runnable flip) {
        int x = this.width / 2 - W / 2, y = 40 + row++ * GAP;
        Button[] ref = new Button[1];
        ref[0] = Button.builder(label(name, get.getAsBoolean()), b -> {
            flip.run(); Config.save(); b.setMessage(label(name, get.getAsBoolean()));
        }).bounds(x, y, W, H).build();
        addRenderableWidget(ref[0]);
    }

    private void step(String name, Runnable next, java.util.function.Supplier<String> val) {
        int x = this.width / 2 - W / 2, y = 40 + row++ * GAP;
        addRenderableWidget(Button.builder(Component.literal(name + ": " + val.get()), b -> {
            next.run(); Config.save(); b.setMessage(Component.literal(name + ": " + val.get()));
        }).bounds(x, y, W, H).build());
    }

    private static Component label(String n, boolean on) {
        return Component.literal(n + ": " + (on ? "AN" : "AUS"));
    }

    @Override
    protected void init() {
        row = 0;
        toggle("Auto Stun Slam", () -> Config.stunSlam, () -> Config.stunSlam = !Config.stunSlam);
        toggle("Auto Spear Swap", () -> Config.spearSwap, () -> Config.spearSwap = !Config.spearSwap);
        toggle("Auto Gapple (niedrige HP)", () -> Config.autoGapple, () -> Config.autoGapple = !Config.autoGapple);
        toggle("HUD anzeigen", () -> Config.showHud, () -> Config.showHud = !Config.showHud);
        toggle("Axt nur bei Schild", () -> Config.stunSlamOnlyIfBlocking,
               () -> Config.stunSlamOnlyIfBlocking = !Config.stunSlamOnlyIfBlocking);
        step("Combo-Pause (Ticks)", () -> Config.stunSlamCooldownTicks =
                Config.stunSlamCooldownTicks >= 60 ? 10 : Config.stunSlamCooldownTicks + 10,
             () -> "" + Config.stunSlamCooldownTicks);
        step("Min. Fallhoehe", () -> Config.minFallDistance =
                Config.minFallDistance >= 4.0 ? 1.0 : Config.minFallDistance + 0.5,
             () -> String.format("%.1f", Config.minFallDistance));
        step("Gapple ab HP", () -> Config.gappleHealth =
                Config.gappleHealth >= 14.0 ? 4.0 : Config.gappleHealth + 2.0,
             () -> String.format("%.0f", Config.gappleHealth));
        addRenderableWidget(Button.builder(Component.literal("Fertig"), b -> onClose())
                .bounds(this.width / 2 - W / 2, 40 + row * GAP + 6, W, H).build());
    }
}

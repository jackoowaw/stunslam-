package dev.pvplite;

import net.fabricmc.loader.api.FabricLoader;
import java.io.*;
import java.nio.file.*;
import java.util.Properties;

/** Config: config/pvplite.properties (wird vom H-Menue geschrieben). */
public class Config {
    // Module an/aus (alle laufen automatisch, keine Hotkeys)
    public static boolean stunSlam = true, spearSwap = true, autoGapple = true, showHud = true;
    // Balance-Werte
    public static int stunSlamDelayMin = 3, stunSlamDelayJitter = 3, stunSlamCooldownTicks = 30;
    public static double minFallDistance = 1.5, minAttackStrength = 0.9;
    public static boolean stunSlamOnlyIfBlocking = true;
    public static int spearReturnTicks = 20, spearCooldownTicks = 40;
    public static double spearTriggerRange = 6.0;
    public static double gappleHealth = 8.0;       // HP (8 = 4 Herzen)
    public static int gappleCooldownTicks = 100;

    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("pvplite.properties");

    public static void load() {
        if (!Files.exists(FILE)) { save(); return; }
        try (InputStream in = Files.newInputStream(FILE)) {
            Properties p = new Properties(); p.load(in);
            stunSlam = b(p, "stunSlam", stunSlam); spearSwap = b(p, "spearSwap", spearSwap);
            autoGapple = b(p, "autoGapple", autoGapple); showHud = b(p, "showHud", showHud);
            stunSlamDelayMin = i(p, "stunSlamDelayMin", stunSlamDelayMin);
            stunSlamDelayJitter = i(p, "stunSlamDelayJitter", stunSlamDelayJitter);
            stunSlamCooldownTicks = i(p, "stunSlamCooldownTicks", stunSlamCooldownTicks);
            minFallDistance = d(p, "minFallDistance", minFallDistance);
            minAttackStrength = d(p, "minAttackStrength", minAttackStrength);
            stunSlamOnlyIfBlocking = b(p, "stunSlamOnlyIfBlocking", stunSlamOnlyIfBlocking);
            spearReturnTicks = i(p, "spearReturnTicks", spearReturnTicks);
            spearCooldownTicks = i(p, "spearCooldownTicks", spearCooldownTicks);
            spearTriggerRange = d(p, "spearTriggerRange", spearTriggerRange);
            gappleHealth = d(p, "gappleHealth", gappleHealth);
            gappleCooldownTicks = i(p, "gappleCooldownTicks", gappleCooldownTicks);
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("stunSlam", "" + stunSlam); p.setProperty("spearSwap", "" + spearSwap);
        p.setProperty("autoGapple", "" + autoGapple); p.setProperty("showHud", "" + showHud);
        p.setProperty("stunSlamDelayMin", "" + stunSlamDelayMin);
        p.setProperty("stunSlamDelayJitter", "" + stunSlamDelayJitter);
        p.setProperty("stunSlamCooldownTicks", "" + stunSlamCooldownTicks);
        p.setProperty("minFallDistance", "" + minFallDistance);
        p.setProperty("minAttackStrength", "" + minAttackStrength);
        p.setProperty("stunSlamOnlyIfBlocking", "" + stunSlamOnlyIfBlocking);
        p.setProperty("spearReturnTicks", "" + spearReturnTicks);
        p.setProperty("spearCooldownTicks", "" + spearCooldownTicks);
        p.setProperty("spearTriggerRange", "" + spearTriggerRange);
        p.setProperty("gappleHealth", "" + gappleHealth);
        p.setProperty("gappleCooldownTicks", "" + gappleCooldownTicks);
        try (OutputStream out = Files.newOutputStream(FILE)) { p.store(out, "PvP Lite"); }
        catch (IOException e) { e.printStackTrace(); }
    }

    private static boolean b(Properties p, String k, boolean d) { return Boolean.parseBoolean(p.getProperty(k, "" + d)); }
    private static int i(Properties p, String k, int d) { return Integer.parseInt(p.getProperty(k, "" + d)); }
    private static double d(Properties p, String k, double d) { return Double.parseDouble(p.getProperty(k, "" + d)); }
}

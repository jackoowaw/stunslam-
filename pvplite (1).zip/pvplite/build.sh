#!/bin/sh
# Voraussetzung: JDK 25 und Gradle installiert
gradle build && echo "Fertig! Mod liegt in build/libs/ (Datei ohne -sources)"

@echo off
REM Voraussetzung: JDK 25 und Gradle installiert (gradle im PATH)
gradle build
echo.
echo Fertig! Die Mod liegt in build\libs\ (die Datei OHNE -sources).
pause

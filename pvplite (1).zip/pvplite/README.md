# PvP Lite (Fabric, MC 26.2)

## Jar bauen - Weg A: GitHub (am einfachsten, nichts installieren)
1. Auf github.com ein neues Repository erstellen und den KOMPLETTEN Inhalt dieses Ordners hochladen
   (inkl. dem versteckten Ordner `.github`).
2. Tab "Actions" -> Workflow "Build" laeuft automatisch (ca. 2-3 Min).
3. Auf den fertigen Lauf klicken -> unten bei "Artifacts" `pvplite-jar` herunterladen -> entpacken.
4. Die Datei OHNE `-sources` bei Modrinth hochladen (Angaben siehe MODRINTH.md).

## Weg B: lokal
JDK 25 + Gradle installieren, dann `build.bat` (Windows) bzw. `./build.sh`. Jar in `build/libs/`.

## Bedienung
Einzige Taste: H = Menue (Module an/aus). Werte: config/pvplite.properties

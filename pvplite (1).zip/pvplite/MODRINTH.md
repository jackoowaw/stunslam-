# Modrinth-Angaben zum Kopieren

**Name:** PvP Lite
**URL/Slug:** pvp-lite
**Kurzbeschreibung (Summary):** Faire PvP-Helfer fuer Fabric 26.2: Auto Stun Slam, Auto Spear Swap, Auto Gapple - alles im Menue (H) an/aus.
**Kategorien:** Utility, Game Mechanics (falls angeboten)
**Client/Server:** Client: required, Server: unsupported
**Lizenz:** MIT

## Beschreibung (Body)
PvP Lite ist eine clientseitige Fabric-Mod fuer Minecraft 26.2.
Mit **H** oeffnest du ein Menue und schaltest jedes Modul einzeln AN oder AUS.

- **Auto Stun Slam:** Axt gegen Schilde, danach Mace-Schlag beim Fall - mit Pausen, kein Auto-Aim
- **Auto Spear Swap:** wechselt beim Sprint auf einen Spieler zu auf den Speer und wieder zurueck
- **Auto Gapple:** isst bei niedriger HP automatisch einen goldenen Apfel
- **HUD** mit Status, alle Werte in `config/pvplite.properties`

Hinweis: Auf vielen Servern sind solche Automatisierungen verboten. Nutze die Mod nur dort, wo sie erlaubt ist.

## Version hochladen
- Datei: `pvplite-1.0.0+26.2.jar` (NICHT die -sources.jar)
- Version number: 1.0.0+26.2
- Loader: Fabric
- Game version: 26.2
- Abhaengigkeit: Fabric API (required)
- Release channel: Release (oder Beta zum Testen)
